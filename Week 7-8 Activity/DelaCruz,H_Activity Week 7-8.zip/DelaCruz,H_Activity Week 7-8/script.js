// Captures our output interface element
const display = document.getElementById('display');

// Appends numbers or operator symbols to our string input values
function appendValue(input) {
    if (display.value === '0' && input !== '.') {
        display.value = input;
    } else {
        display.value += input;
    }
}

// Empties out the display completely (Clear function)
function clearDisplay() {
    display.value = '';
}

// Evaluates the string expression mathematically and handles computation errors safely
function calculateResult() {
    try {
        // If empty display field, change nothing
        if (display.value === '') return;

        // Evaluates the standard string logic equation input natively
        const result = eval(display.value);
        
        // Formats fractions or long numbers cleanly so they don't break outside boundaries
        if (Number.isInteger(result)) {
            display.value = result;
        } else {
            display.value = parseFloat(result.toFixed(4));
        }
    } 
    catch (error) {
        // Displays error explicitly if syntax structure rules fail
        display.value = "Error";
    }
}