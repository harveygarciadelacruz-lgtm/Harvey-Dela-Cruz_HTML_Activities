// SELECT CONCEPT TABS AND DISPLAY BOX
const domBtn = document.getElementById('domBtn');
const eventBtn = document.getElementById('eventBtn');
const dynamicBtn = document.getElementById('dynamicBtn');
const conceptDisplay = document.getElementById('conceptDisplay');

// FUNCTION TO RESET ACTIVE CLASS
function switchActiveTab(activeButton) {
    domBtn.classList.remove('card-active');
    eventBtn.classList.remove('card-active');
    dynamicBtn.classList.remove('card-active');
    
    activeButton.classList.add('card-active');
}

// LISTENERS FOR THE INFOGRAPHIC TABS
domBtn.addEventListener('click', () => {
    switchActiveTab(domBtn);
    conceptDisplay.style.borderLeftColor = "#4fcfb2";
    conceptDisplay.innerHTML = `Active Concept: <strong>DOM Structure</strong>. Managing the parental HTML list tree and removing nodes on command!`;
});

eventBtn.addEventListener('click', () => {
    switchActiveTab(eventBtn);
    conceptDisplay.style.borderLeftColor = "#e2b353";
    conceptDisplay.innerHTML = `Active Concept: <strong>Event Handling</strong>. Currently managing user text submissions and click actions!`;
});

dynamicBtn.addEventListener('click', () => {
    switchActiveTab(dynamicBtn);
    conceptDisplay.style.borderLeftColor = "#f87171";
    conceptDisplay.innerHTML = `Active Concept: <strong>Dynamic Content</strong>. Generating fully custom HTML list items out of thin air using JavaScript strings!`;
});


// ==========================================
// KEEP YOUR EXISTING TASK CODE BELOW THIS LINE
// ==========================================
const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const taskList = document.getElementById('taskList');

addTaskBtn.addEventListener('click', createNewTask);
taskInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') createNewTask();
});

function createNewTask() {
    const taskText = taskInput.value.trim();
    if (taskText === '') return;

    const li = document.createElement('li');
    li.className = 'task-item';
    li.innerHTML = `
        <span>${taskText}</span>
        <div class="task-actions">
            <button class="action-btn complete-btn">✓</button>
            <button class="action-btn delete-btn">✕</button>
        </div>
    `;

    const completeBtn = li.querySelector('.complete-btn');
    const deleteBtn = li.querySelector('.delete-btn');

    completeBtn.addEventListener('click', () => li.classList.toggle('completed'));
    deleteBtn.addEventListener('click', () => li.remove());

    taskList.appendChild(li);
    taskInput.value = '';
    taskInput.focus();
}