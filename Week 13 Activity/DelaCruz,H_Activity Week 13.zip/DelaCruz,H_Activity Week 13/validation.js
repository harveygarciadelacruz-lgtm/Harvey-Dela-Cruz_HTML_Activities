document.addEventListener('DOMContentLoaded', function () {
    // Collect all forms we want to apply Bootstrap validation styles to
    const form = document.getElementById('bootstrapForm');
    const messageField = document.getElementById('inputMessage');
    const messageFeedback = document.getElementById('messageFeedback');

    form.addEventListener('submit', function (event) {
        // Custom rule confirmation: Check minimum length of 20 characters requirement
        const messageValue = messageField.value.trim();
        
        if (messageValue.length < 20) {
            // Force dynamic failure properties on field state
            messageField.setCustomValidity("Invalid");
            messageFeedback.textContent = `Message too short! You typed ${messageValue.length} characters, but it must be at least 20.`;
        } else {
            // Reset validation errors if criteria is met successfully
            messageField.setCustomValidity("");
        }

        // Evaluate standard state compliance rules natively 
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        } else {
            event.preventDefault(); // Stop page reload for simulation demonstration purposes
            alert('🎉 Form submitted successfully! All Bootstrap validation checks passed.');
            
            // Programmatically hide modal window upon submission success
            const modalElement = document.getElementById('contactModal');
            const modalInstance = bootstrap.Modal.getInstance(modalElement);
            modalInstance.hide();
            
            form.reset();
            form.classList.remove('was-validated');
            return;
        }

        // Apply active bootstrap status flag updates globally across the form field nodes
        form.classList.add('was-validated');
    }, false);

    // Dynamic input monitoring cleanup: clear custom validity errors as the user actively types
    messageField.addEventListener('input', function() {
        if (messageField.value.trim().length >= 20) {
            messageField.setCustomValidity("");
        }
    });
});